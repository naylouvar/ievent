﻿// Developer Express Code Central Example:
// How to use All-Day header to display scheduled time statistics
// 
// Problem : It would be good to display how much time you have in use (% wise) in
// your schedule. When an appointment is added/changed/deleted for each resource it
// will calculate the appointments on the days that have been changed against your
// total time available and get a % which will be added to the top of the schedule.
// When you have less than 50% available it will show yellow and when you go over
// 50% it will show in red. Solution: You can utilize the
// SchedulerControl.CustomDrawDayViewAllDayArea event to draw this statistics in
// the All-Day appointments area. Then, you can collect appointments for a
// particular day via the SchedulerStorageBase.GetAppointments method. This
// approach is illustrated by the following example.
// 
// You can find sample updates and versions for different programming languages here:
// http://www.devexpress.com/example=E121

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("iEvent")]
[assembly: AssemblyDescription("Réservation & Evenements")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("OURBATI GROUP")]
[assembly: AssemblyProduct("iEvent v1.0.0")]
[assembly: AssemblyCopyright("Copyright © - 2007")]
[assembly: AssemblyTrademark("iEvent TM")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("52c60a0e-6c0e-43d9-872c-cb719ed07ee2")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
